<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/v1/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GXX0klkhz5HwqVOy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FyZdRioeeSvSzrOD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5zoYKjOxDHj8H2jo',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/get' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lanv16sohuR3cLye',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a7wd3J6DrvQVbPji',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/leads' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qVwidlKhYVOcYrtZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u7l9vmpu5Jm3byoA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/quotes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8EaZMhh7S4QRPwLZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ib1M86QVlw68YETU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/mails' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eeexbbBGdBBpkdSj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BLn8cvbMT91nFbwH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/activities' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CSNRk4R6DurGTzyU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ko1N1DghA0HXOOuL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/contacts/persons' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8XkNlk61oGm9rHXF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::24pfRZNJxb0ksS2k',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/contacts/organizations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NI86vmOQqCsADjm7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SN3gRTc8JapFH1rs',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xBT1z1J98Hv95l1B',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TY0SzGCvaeSYzQKu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/groups' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lpzxHo2Kqeq8CDbT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7cLGazwpS5OmqgF0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aJdJU9di5kM1QFNq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z9XTocyP4MKl6rFb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fAVWUQhjgA0kCRnw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KXbdHwIv3DPYAYM9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/pipelines' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pCL7TzHupvi0uEcc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gaoyqU9Usg5YptZD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/sources' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T4Q7lmitt0t03HLV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V1u9q7rJnlILSKNi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/types' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4bBuldvkraEdKisa',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bXbKOUMMyPkkPece',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/attributes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Iw1OA34Ut5lkjj4q',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VazbUqWFqOeyvF4D',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/email-templates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SyzPv41GZt6UcKHn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::USj1gAYEscjg1wrF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/workflows' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gburmdPEh0QVu2Zc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Gn6b3FSi1cuK6x4m',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/settings/tags' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6IBiEdsSpyJlweEC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TWB8nN24tdus0HEi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_debugbar/open' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.openhandler',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_debugbar/assets/stylesheets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.assets.css',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_debugbar/assets/javascript' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.assets.js',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sY0OqzMI4Ue1YxZc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xku2l1aozMbUQiA4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'krayin.home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tautkxCfhN4DyrCS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.session.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.session.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.forgot_password.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.forgot_password.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.reset_password.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/mail/inbound-parse' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.mail.inbound_parse',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.session.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dashboard.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/template' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dashboard.template',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/api/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.api.dashboard.card.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/api/dashboard/cards' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.api.dashboard.cards.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.api.dashboard.cards.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/account' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.user.account.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/account/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.user.account.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/leads/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/leads/search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/quotes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quotes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/activities' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activities.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/activities/get' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activities.get',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/activities/is-overlapping' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activities.check_overlapping',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/activities/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activities.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/activities/search-participants' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activities.search_participants',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/activities/file-upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activities.file_upload',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/mail/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.mail.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/contacts/persons' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.persons.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/contacts/persons/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.persons.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.persons.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/contacts/persons/search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.persons.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/contacts/organizations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.organizations.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/contacts/organizations/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.organizations.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.organizations.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/products/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/products/search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/groups' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.groups.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/groups/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.groups.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.groups.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.roles.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/roles/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.roles.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.roles.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.users.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/users/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.users.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.users.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/attributes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.attributes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/attributes/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.attributes.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.attributes.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/pipelines' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.pipelines.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/pipelines/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.pipelines.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.pipelines.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/sources' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.sources.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/sources/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.sources.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/types' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.types.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/types/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.types.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/email-templates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.email_templates.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/email-templates/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.email_templates.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.email_templates.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/workflows' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.workflows.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/workflows/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.workflows.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.workflows.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/tags' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.tags.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/tags/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.tags.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings/tags/search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.tags.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ui.datagrid.export',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/web-forms' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.web_forms.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/web-forms/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.web_forms.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.web_forms.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/a(?|pi/v1/(?|leads/(?|([^/]++)(?|(*:41))|mass\\-(?|update(*:64)|destroy(*:78))|([^/]++)/(?|tags(?|(*:105))|quotes(?|(*:123))))|quotes/(?|([^/]++)(?|(*:155))|mass\\-destroy(*:177))|mails(?|/([^/]++)(*:203)|(?:/([^/]++))?(?|(*:228))|/(?|mass\\-(?|update(*:256)|destroy(*:271))|attachment\\-download(?:/([^/]++))?(*:314)))|activities(?|/(?|([^/]++)(*:349)|is\\-overlapping(*:372))|(?:/([^/]++))?(*:395)|/file\\-(?|upload(*:419)|download(?:/([^/]++))?(*:449))|(?:/([^/]++))?(*:472)|/mass\\-(?|update(*:496)|destroy(*:511)))|con(?|tacts/(?|persons/(?|([^/]++)(*:555)|search(*:569)|([^/]++)(?|(*:588))|mass\\-destroy(*:610))|organizations/(?|([^/]++)(?|(*:647))|mass\\-destroy(*:669)))|figuration(?:/([^/]++))?(*:703))|products/(?|([^/]++)(*:732)|search(*:746)|([^/]++)(?|(*:765))|mass\\-destroy(*:787))|settings/(?|groups/([^/]++)(?|(*:826))|roles/([^/]++)(?|(*:852))|users/(?|([^/]++)(?|(*:881))|mass\\-(?|update(*:905)|destroy(*:920)))|pipelines/([^/]++)(?|(*:951))|sources/([^/]++)(?|(*:979))|t(?|ypes/([^/]++)(?|(*:1008))|ags/(?|([^/]++)(?|(*:1036))|mass\\-destroy(*:1059)))|attributes/(?|([^/]++)(*:1092)|lookup(?:/([^/]++))?(*:1121)|([^/]++)(?|(*:1141))|mass\\-destroy(*:1164))|email\\-templates/([^/]++)(?|(*:1202))|workflows/([^/]++)(?|(*:1233))))|dmin/(?|reset\\-password/([^/]++)(*:1277)|leads(?|/(?|view(?:/([^/]++))?(*:1316)|edit(?:/([^/]++))?(*:1343)|([^/]++)(*:1360)|mass\\-(?|update(*:1384)|destroy(*:1400))|tags/([^/]++)(*:1423)|([^/]++)(?:/([^/]++))?(*:1454)|get(?:/([^/]++))?(*:1480))|(?:/([^/]++))?(*:1504)|/quotes/([^/]++)(?:/([^/]++))?(*:1543))|quotes/(?|create(?|(?:/([^/]++))?(*:1586)|(*:1595))|edit(?|(?:/([^/]++))?(*:1626)|/([^/]++)(*:1644))|print(?:/([^/]++))?(*:1673)|([^/]++)(*:1690)|mass\\-destroy(*:1712))|activities(?|/(?|edit(?:/([^/]++))?(?|(*:1760))|file\\-download(?:/([^/]++))?(*:1798))|(?:/([^/]++))?(*:1822)|/mass\\-(?|update(*:1847)|destroy(*:1863)))|mail(?|/(?|edit(?:/([^/]++))?(*:1903)|attachment\\-download(?:/([^/]++))?(*:1946))|(?:/([^/]++))?(*:1970)|(?:/([^/]++)(?:/([^/]++))?)?(*:2007)|(?:/([^/]++))?(*:2030)|/mass\\-(?|update(*:2055)|destroy(*:2071)))|con(?|tacts/(?|persons/(?|edit(?|(?:/([^/]++))?(*:2129)|/([^/]++)(*:2147))|([^/]++)(*:2165)|mass\\-destroy(*:2187))|organizations/(?|edit(?|(?:/([^/]++))?(*:2235)|/([^/]++)(*:2253))|([^/]++)(*:2271)|mass\\-destroy(*:2293)))|figuration(?:/([^/]++))?(?|(*:2331)))|products/(?|edit/([^/]++)(?|(*:2370))|([^/]++)(*:2388)|mass\\-destroy(*:2410))|settings/(?|groups/(?|edit/([^/]++)(?|(*:2458))|([^/]++)(*:2476))|roles/(?|edit/([^/]++)(?|(*:2511))|([^/]++)(*:2529))|users/(?|edit(?|(?:/([^/]++))?(*:2569)|/([^/]++)(*:2587))|([^/]++)(*:2605)|mass\\-(?|update(*:2629)|destroy(*:2645)))|attributes/(?|edit/([^/]++)(?|(*:2686))|lookup(?|(?:/([^/]++))?(*:2719)|\\-entity(?:/([^/]++))?(*:2750))|([^/]++)(*:2768)|mass\\-(?|update(*:2792)|destroy(*:2808))|download(*:2826))|pipelines/(?|edit(?|(?:/([^/]++))?(*:2870)|/([^/]++)(*:2888))|([^/]++)(*:2906))|sources/(?|edit(?|(?:/([^/]++))?(*:2948)|/([^/]++)(*:2966))|([^/]++)(*:2984))|t(?|ypes/(?|edit(?|(?:/([^/]++))?(*:3027)|/([^/]++)(*:3045))|([^/]++)(*:3063))|ags/(?|edit(?|(?:/([^/]++))?(*:3101)|/([^/]++)(*:3119))|([^/]++)(*:3137)|mass\\-destroy(*:3159)))|email\\-templates/(?|edit(?|(?:/([^/]++))?(*:3211)|/([^/]++)(*:3229))|([^/]++)(*:3247))|workflows/(?|edit(?|(?:/([^/]++))?(*:3291)|/([^/]++)(*:3309))|([^/]++)(*:3327)))|web\\-forms/(?|form(?|s/([^/]++)(?|/form\\.(?|js(*:3384)|html(*:3397))|(*:3407))|/([^/]++)/form\\.html(*:3437))|edit(?|(?:/([^/]++))?(*:3468)|/([^/]++)(*:3486))|([^/]++)(*:3504))))|/_debugbar/c(?|lockwork/([^/]++)(*:3548)|ache/([^/]++)(?:/([^/]++))?(*:3584)))/?$}sDu',
    ),
    3 => 
    array (
      41 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CKCR3fcZn7iAsCDB',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4tA0BZvWsmJrNLZG',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UIRyfIzjf8MvALDU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      64 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5P7v4KjpT8OZx4Tx',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      78 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IWZlfy7TSSPEU496',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      105 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5CZwIqpQ6axQYFL6',
          ),
          1 => 
          array (
            0 => 'lead_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ADUn0R24eQF5P8Oo',
          ),
          1 => 
          array (
            0 => 'lead_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      123 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KP61eLHYkumOJtey',
          ),
          1 => 
          array (
            0 => 'lead_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WBy76RqSZogBlc46',
          ),
          1 => 
          array (
            0 => 'lead_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      155 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4XVu9uwjs78fcyr3',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nPprRni6cH5tgyjy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OM7hD3MOwszHM3H6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      177 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ekkRuX2OhO4Yl1qv',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      203 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1VHW04IYoZoe5hDs',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      228 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DtSOi4yy40yzNDGL',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H6Hiq5kVKZoNFn5u',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      256 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0dA4m7aacGzX6QVH',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      271 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jDNhP5mcuJUocw8B',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      314 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Bo9tpvCxy5jJBBT2',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      349 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8oNuD9G959mhksCl',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      372 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KzvgMGlfHTa07FFW',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      395 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eFsihRs7MQc4usoO',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      419 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZcnO7fZZfzuc5lCZ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      449 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::58OfFOneNlV2CAfz',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      472 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WljcrQ0B9KgKSYOd',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      496 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M9gTn6nX5Bv5AY5y',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      511 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eIB9heL5XSbU76GZ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      555 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gVLmmLgO1468OAuT',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      569 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wmhTNurmrNIDwCIW',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      588 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rrPDXNI5pfoi6V6z',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SHXduyQ9MbtPdeTI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      610 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N1xgq8xRwB65mWGw',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      647 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8p1Zv8Rqe6z5KRNp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MKT7afvcns3odnm1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OhaLbiqlKrMIhAld',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      669 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3cf5cUQa2BcU5xWm',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      703 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vogrvHLSRLgKvA4W',
            'slug' => NULL,
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      732 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4MnNhUguGeI0lwng',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      746 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ptVAo0YUFq2BgWrp',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      765 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iOcOBZ3eVGgtioqs',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::amu8Jk0Ua7bmoqak',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      787 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GT8Kewm4BK133mSc',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      826 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HJKLLXsglMg07luN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xCrDzjVNKxrrbKH8',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2DeRXgl2bRUUYIln',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      852 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PS81V8Ahx5Y4ojCc',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EdXX4PM8T8yKsrYf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G84Ucjc9XFSUmi9d',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      881 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N5bFPlcmYZjt31ck',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Fo85sySqmHjkJ4bt',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::toBDWgfhNOmk1jXo',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      905 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R9FgR0NdyxncGwSx',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      920 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pFB5IDZeG3RWcUhz',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      951 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JVSiZkMPqVD6QACX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Mp2sNL2TM0kKHBdw',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8MciWs3SajJbk9aZ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      979 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fX5HDAxwySXgIuJn',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LxLS3KsGJJqFHQco',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tANXt8yGLp8DLJts',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1008 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7koVjCHbVOPrcI4a',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CDvGU36h1Mw4fh2e',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dE1hEAKpV63lmB0X',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1036 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tWI9LTGYQWmzluha',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cn3Gx9Uz2ZQYzLQ6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qwaTygMp0AClsddH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1059 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6L8xBdsg8LX0k84X',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1092 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CDIyihFLid6ZiYoA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1121 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iZYDRcAEcT6sUgo8',
            'lookup' => NULL,
          ),
          1 => 
          array (
            0 => 'lookup',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1141 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C6VuWrYNnz3jg5Bu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::o6y7beLt5onQNHSH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1164 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::n0lpxI6wr7AaIIjU',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1202 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NgZpaDVwkKXW7WHI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z48VDodtBbCxdMhl',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ru2DEN8JAuJdTo2y',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1233 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5PNcCwghH8aOTYGM',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vCkW2yb2hEI71tLJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AS9hwM1gi1RlYWst',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1277 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.reset_password.create',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1316 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.view',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1343 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.update',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1360 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1384 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.mass_update',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1400 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.mass_delete',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1423 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.tags.store',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1454 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.tags.delete',
            'tag_id' => NULL,
          ),
          1 => 
          array (
            0 => 'lead_id',
            1 => 'tag_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1480 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.get',
            'pipeline_id' => NULL,
          ),
          1 => 
          array (
            0 => 'pipeline_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1504 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.index',
            'pipeline_id' => NULL,
          ),
          1 => 
          array (
            0 => 'pipeline_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1543 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leads.quotes.delete',
            'quote_id' => NULL,
          ),
          1 => 
          array (
            0 => 'lead_id',
            1 => 'quote_id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1586 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quotes.create',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1595 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quotes.store',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1626 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quotes.edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1644 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quotes.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1673 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quotes.print',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1690 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quotes.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1712 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quotes.mass_delete',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1760 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activities.edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activities.update',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1798 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activities.file_download',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1822 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activities.delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1847 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activities.mass_update',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1863 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activities.mass_delete',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1903 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.mail.update',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1946 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.mail.attachment_download',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1970 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.mail.index',
            'route' => NULL,
          ),
          1 => 
          array (
            0 => 'route',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2007 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.mail.view',
            'route' => NULL,
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'route',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2030 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.mail.delete',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2055 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.mail.mass_update',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2071 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.mail.mass_delete',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2129 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.persons.edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2147 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.persons.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2165 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.persons.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2187 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.persons.mass_delete',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2235 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.organizations.edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2253 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.organizations.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2271 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.organizations.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2293 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.contacts.organizations.mass_delete',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2331 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.configuration.index',
            'slug' => NULL,
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.configuration.index.store',
            'slug' => NULL,
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2370 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2388 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2410 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.mass_delete',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2458 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.groups.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.groups.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2476 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.groups.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2511 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.roles.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.roles.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2529 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.roles.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2569 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.users.edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2587 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.users.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2605 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.users.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2629 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.users.mass_update',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2645 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.users.mass_delete',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2686 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.attributes.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.attributes.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2719 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.attributes.lookup',
            'lookup' => NULL,
          ),
          1 => 
          array (
            0 => 'lookup',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2750 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.attributes.lookup_entity',
            'lookup' => NULL,
          ),
          1 => 
          array (
            0 => 'lookup',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2768 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.attributes.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2792 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.attributes.mass_update',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2808 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.attributes.mass_delete',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2826 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.attributes.download',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2870 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.pipelines.edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2888 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.pipelines.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2906 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.pipelines.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2948 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.sources.edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2966 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.sources.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2984 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.sources.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3027 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.types.edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3045 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.types.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3063 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.types.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3101 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.tags.edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3119 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.tags.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3137 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.tags.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3159 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.tags.mass_delete',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3211 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.email_templates.edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3229 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.email_templates.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3247 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.email_templates.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3291 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.workflows.edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3309 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.workflows.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3327 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.workflows.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3384 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.web_forms.form_js',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3397 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.web_forms.preview',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3407 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.web_forms.form_store',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3437 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.web_forms.view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3468 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.web_forms.edit',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3486 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.web_forms.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3504 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.web_forms.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3548 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.clockwork',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3584 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.cache.delete',
            'tags' => NULL,
          ),
          1 => 
          array (
            0 => 'key',
            1 => 'tags',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::GXX0klkhz5HwqVOy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\User\\AuthController@login',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\User\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::GXX0klkhz5HwqVOy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FyZdRioeeSvSzrOD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\User\\AuthController@forgotPassword',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\User\\AuthController@forgotPassword',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::FyZdRioeeSvSzrOD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5zoYKjOxDHj8H2jo' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\User\\AuthController@logout',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\User\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::5zoYKjOxDHj8H2jo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lanv16sohuR3cLye' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\User\\AccountController@get',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\User\\AccountController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::lanv16sohuR3cLye',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a7wd3J6DrvQVbPji' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\User\\AccountController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\User\\AccountController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::a7wd3J6DrvQVbPji',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qVwidlKhYVOcYrtZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/leads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::qVwidlKhYVOcYrtZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CKCR3fcZn7iAsCDB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/leads/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::CKCR3fcZn7iAsCDB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::u7l9vmpu5Jm3byoA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/leads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::u7l9vmpu5Jm3byoA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4tA0BZvWsmJrNLZG' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/leads/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::4tA0BZvWsmJrNLZG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UIRyfIzjf8MvALDU' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/leads/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::UIRyfIzjf8MvALDU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5P7v4KjpT8OZx4Tx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/leads/mass-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@massUpdate',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@massUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::5P7v4KjpT8OZx4Tx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IWZlfy7TSSPEU496' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/leads/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@massDestroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\LeadController@massDestroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::IWZlfy7TSSPEU496',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5CZwIqpQ6axQYFL6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/leads/{lead_id}/tags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\TagController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\TagController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::5CZwIqpQ6axQYFL6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ADUn0R24eQF5P8Oo' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/leads/{lead_id}/tags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\TagController@delete',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\TagController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ADUn0R24eQF5P8Oo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KP61eLHYkumOJtey' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/leads/{lead_id}/quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\QuoteController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\QuoteController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::KP61eLHYkumOJtey',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WBy76RqSZogBlc46' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/leads/{lead_id}/quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\QuoteController@delete',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Lead\\QuoteController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::WBy76RqSZogBlc46',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8EaZMhh7S4QRPwLZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Quote\\QuoteController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Quote\\QuoteController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::8EaZMhh7S4QRPwLZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4XVu9uwjs78fcyr3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/quotes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Quote\\QuoteController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Quote\\QuoteController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::4XVu9uwjs78fcyr3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ib1M86QVlw68YETU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Quote\\QuoteController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Quote\\QuoteController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ib1M86QVlw68YETU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nPprRni6cH5tgyjy' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/quotes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Quote\\QuoteController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Quote\\QuoteController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::nPprRni6cH5tgyjy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OM7hD3MOwszHM3H6' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/quotes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Quote\\QuoteController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Quote\\QuoteController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::OM7hD3MOwszHM3H6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ekkRuX2OhO4Yl1qv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/quotes/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Quote\\QuoteController@massDestroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Quote\\QuoteController@massDestroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ekkRuX2OhO4Yl1qv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eeexbbBGdBBpkdSj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/mails',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::eeexbbBGdBBpkdSj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1VHW04IYoZoe5hDs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/mails/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::1VHW04IYoZoe5hDs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BLn8cvbMT91nFbwH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/mails',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::BLn8cvbMT91nFbwH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DtSOi4yy40yzNDGL' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/mails/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::DtSOi4yy40yzNDGL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H6Hiq5kVKZoNFn5u' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/mails/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::H6Hiq5kVKZoNFn5u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0dA4m7aacGzX6QVH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/mails/mass-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@massUpdate',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@massUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::0dA4m7aacGzX6QVH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jDNhP5mcuJUocw8B' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/mails/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@massDestroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@massDestroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::jDNhP5mcuJUocw8B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Bo9tpvCxy5jJBBT2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/mails/attachment-download/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@download',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Mail\\EmailController@download',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::Bo9tpvCxy5jJBBT2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CSNRk4R6DurGTzyU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/activities',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::CSNRk4R6DurGTzyU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8oNuD9G959mhksCl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/activities/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::8oNuD9G959mhksCl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KzvgMGlfHTa07FFW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activities/is-overlapping',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@checkIfOverlapping',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@checkIfOverlapping',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::KzvgMGlfHTa07FFW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ko1N1DghA0HXOOuL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activities',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ko1N1DghA0HXOOuL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eFsihRs7MQc4usoO' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/activities/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::eFsihRs7MQc4usoO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZcnO7fZZfzuc5lCZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activities/file-upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@upload',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@upload',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ZcnO7fZZfzuc5lCZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::58OfFOneNlV2CAfz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/activities/file-download/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@download',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@download',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::58OfFOneNlV2CAfz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WljcrQ0B9KgKSYOd' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/activities/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::WljcrQ0B9KgKSYOd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M9gTn6nX5Bv5AY5y' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activities/mass-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@massUpdate',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@massUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::M9gTn6nX5Bv5AY5y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eIB9heL5XSbU76GZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activities/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@massDestroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Activity\\ActivityController@massDestroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::eIB9heL5XSbU76GZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8XkNlk61oGm9rHXF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/contacts/persons',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::8XkNlk61oGm9rHXF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gVLmmLgO1468OAuT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/contacts/persons/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::gVLmmLgO1468OAuT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wmhTNurmrNIDwCIW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/contacts/persons/search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@search',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@search',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::wmhTNurmrNIDwCIW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::24pfRZNJxb0ksS2k' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/contacts/persons',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::24pfRZNJxb0ksS2k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rrPDXNI5pfoi6V6z' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/contacts/persons/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::rrPDXNI5pfoi6V6z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SHXduyQ9MbtPdeTI' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/contacts/persons/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::SHXduyQ9MbtPdeTI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::N1xgq8xRwB65mWGw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/contacts/persons/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@massDestroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\PersonController@massDestroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::N1xgq8xRwB65mWGw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NI86vmOQqCsADjm7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/contacts/organizations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\OrganizationController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\OrganizationController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::NI86vmOQqCsADjm7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8p1Zv8Rqe6z5KRNp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/contacts/organizations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\OrganizationController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\OrganizationController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::8p1Zv8Rqe6z5KRNp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SN3gRTc8JapFH1rs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/contacts/organizations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\OrganizationController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\OrganizationController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::SN3gRTc8JapFH1rs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MKT7afvcns3odnm1' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/contacts/organizations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\OrganizationController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\OrganizationController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::MKT7afvcns3odnm1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OhaLbiqlKrMIhAld' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/contacts/organizations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\OrganizationController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\OrganizationController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::OhaLbiqlKrMIhAld',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3cf5cUQa2BcU5xWm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/contacts/organizations/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\OrganizationController@massDestroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Contact\\OrganizationController@massDestroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/contacts',
        'where' => 
        array (
        ),
        'as' => 'generated::3cf5cUQa2BcU5xWm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xBT1z1J98Hv95l1B' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::xBT1z1J98Hv95l1B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4MnNhUguGeI0lwng' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/products/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::4MnNhUguGeI0lwng',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ptVAo0YUFq2BgWrp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/products/search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@search',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@search',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ptVAo0YUFq2BgWrp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TY0SzGCvaeSYzQKu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::TY0SzGCvaeSYzQKu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iOcOBZ3eVGgtioqs' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/products/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::iOcOBZ3eVGgtioqs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::amu8Jk0Ua7bmoqak' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/products/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::amu8Jk0Ua7bmoqak',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GT8Kewm4BK133mSc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/products/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@massDestroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Product\\ProductController@massDestroy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::GT8Kewm4BK133mSc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lpzxHo2Kqeq8CDbT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\GroupController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\GroupController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::lpzxHo2Kqeq8CDbT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HJKLLXsglMg07luN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/groups/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\GroupController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\GroupController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::HJKLLXsglMg07luN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7cLGazwpS5OmqgF0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\GroupController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\GroupController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::7cLGazwpS5OmqgF0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xCrDzjVNKxrrbKH8' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/settings/groups/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\GroupController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\GroupController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::xCrDzjVNKxrrbKH8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2DeRXgl2bRUUYIln' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/settings/groups/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\GroupController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\GroupController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::2DeRXgl2bRUUYIln',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aJdJU9di5kM1QFNq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\RoleController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\RoleController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::aJdJU9di5kM1QFNq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PS81V8Ahx5Y4ojCc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/roles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\RoleController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\RoleController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::PS81V8Ahx5Y4ojCc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z9XTocyP4MKl6rFb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\RoleController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\RoleController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::z9XTocyP4MKl6rFb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EdXX4PM8T8yKsrYf' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/settings/roles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\RoleController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\RoleController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::EdXX4PM8T8yKsrYf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::G84Ucjc9XFSUmi9d' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/settings/roles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\RoleController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\RoleController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::G84Ucjc9XFSUmi9d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fAVWUQhjgA0kCRnw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::fAVWUQhjgA0kCRnw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::N5bFPlcmYZjt31ck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/users/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::N5bFPlcmYZjt31ck',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KXbdHwIv3DPYAYM9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::KXbdHwIv3DPYAYM9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Fo85sySqmHjkJ4bt' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/settings/users/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::Fo85sySqmHjkJ4bt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::toBDWgfhNOmk1jXo' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/settings/users/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::toBDWgfhNOmk1jXo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::R9FgR0NdyxncGwSx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/users/mass-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@massUpdate',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@massUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::R9FgR0NdyxncGwSx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pFB5IDZeG3RWcUhz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/users/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@massDestroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\UserController@massDestroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::pFB5IDZeG3RWcUhz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pCL7TzHupvi0uEcc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/pipelines',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\PipelineController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\PipelineController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::pCL7TzHupvi0uEcc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JVSiZkMPqVD6QACX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/pipelines/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\PipelineController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\PipelineController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::JVSiZkMPqVD6QACX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gaoyqU9Usg5YptZD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/pipelines',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\PipelineController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\PipelineController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::gaoyqU9Usg5YptZD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Mp2sNL2TM0kKHBdw' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/settings/pipelines/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\PipelineController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\PipelineController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::Mp2sNL2TM0kKHBdw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8MciWs3SajJbk9aZ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/settings/pipelines/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\PipelineController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\PipelineController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::8MciWs3SajJbk9aZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::T4Q7lmitt0t03HLV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/sources',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\SourceController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\SourceController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::T4Q7lmitt0t03HLV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fX5HDAxwySXgIuJn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/sources/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\SourceController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\SourceController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::fX5HDAxwySXgIuJn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::V1u9q7rJnlILSKNi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/sources',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\SourceController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\SourceController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::V1u9q7rJnlILSKNi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LxLS3KsGJJqFHQco' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/settings/sources/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\SourceController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\SourceController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::LxLS3KsGJJqFHQco',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tANXt8yGLp8DLJts' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/settings/sources/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\SourceController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\SourceController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::tANXt8yGLp8DLJts',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4bBuldvkraEdKisa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/types',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TypeController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TypeController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::4bBuldvkraEdKisa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7koVjCHbVOPrcI4a' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/types/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TypeController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TypeController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::7koVjCHbVOPrcI4a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bXbKOUMMyPkkPece' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/types',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TypeController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TypeController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::bXbKOUMMyPkkPece',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CDvGU36h1Mw4fh2e' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/settings/types/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TypeController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TypeController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::CDvGU36h1Mw4fh2e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dE1hEAKpV63lmB0X' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/settings/types/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TypeController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TypeController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::dE1hEAKpV63lmB0X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Iw1OA34Ut5lkjj4q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/attributes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::Iw1OA34Ut5lkjj4q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CDIyihFLid6ZiYoA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/attributes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::CDIyihFLid6ZiYoA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iZYDRcAEcT6sUgo8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/attributes/lookup/{lookup?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@lookup',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@lookup',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::iZYDRcAEcT6sUgo8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VazbUqWFqOeyvF4D' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/attributes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::VazbUqWFqOeyvF4D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::C6VuWrYNnz3jg5Bu' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/settings/attributes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::C6VuWrYNnz3jg5Bu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::o6y7beLt5onQNHSH' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/settings/attributes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::o6y7beLt5onQNHSH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::n0lpxI6wr7AaIIjU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/attributes/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@massDestroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\AttributeController@massDestroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::n0lpxI6wr7AaIIjU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SyzPv41GZt6UcKHn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/email-templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\EmailTemplateController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\EmailTemplateController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::SyzPv41GZt6UcKHn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NgZpaDVwkKXW7WHI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/email-templates/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\EmailTemplateController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\EmailTemplateController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::NgZpaDVwkKXW7WHI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::USj1gAYEscjg1wrF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/email-templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\EmailTemplateController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\EmailTemplateController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::USj1gAYEscjg1wrF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z48VDodtBbCxdMhl' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/settings/email-templates/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\EmailTemplateController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\EmailTemplateController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::z48VDodtBbCxdMhl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ru2DEN8JAuJdTo2y' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/settings/email-templates/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\EmailTemplateController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\EmailTemplateController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::Ru2DEN8JAuJdTo2y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gburmdPEh0QVu2Zc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/workflows',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\WorkflowController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\WorkflowController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::gburmdPEh0QVu2Zc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5PNcCwghH8aOTYGM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/workflows/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\WorkflowController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\WorkflowController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::5PNcCwghH8aOTYGM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Gn6b3FSi1cuK6x4m' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/workflows',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\WorkflowController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\WorkflowController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::Gn6b3FSi1cuK6x4m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vCkW2yb2hEI71tLJ' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/settings/workflows/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\WorkflowController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\WorkflowController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::vCkW2yb2hEI71tLJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AS9hwM1gi1RlYWst' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/settings/workflows/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\WorkflowController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\WorkflowController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::AS9hwM1gi1RlYWst',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6IBiEdsSpyJlweEC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/tags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TagController@index',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TagController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::6IBiEdsSpyJlweEC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tWI9LTGYQWmzluha' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/settings/tags/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TagController@show',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TagController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::tWI9LTGYQWmzluha',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TWB8nN24tdus0HEi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/tags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TagController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TagController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::TWB8nN24tdus0HEi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cn3Gx9Uz2ZQYzLQ6' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/settings/tags/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TagController@update',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TagController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::cn3Gx9Uz2ZQYzLQ6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qwaTygMp0AClsddH' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/settings/tags/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TagController@destroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TagController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::qwaTygMp0AClsddH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6L8xBdsg8LX0k84X' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/settings/tags/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TagController@massDestroy',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Setting\\TagController@massDestroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::6L8xBdsg8LX0k84X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vogrvHLSRLgKvA4W' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/configuration/{slug?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Configuration\\ConfigurationController@store',
        'controller' => 'Webkul\\RestApi\\Http\\Controllers\\V1\\Configuration\\ConfigurationController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::vogrvHLSRLgKvA4W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.openhandler' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_debugbar/open',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\OpenHandlerController@handle',
        'as' => 'debugbar.openhandler',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\OpenHandlerController@handle',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.clockwork' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_debugbar/clockwork/{id}',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\OpenHandlerController@clockwork',
        'as' => 'debugbar.clockwork',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\OpenHandlerController@clockwork',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.assets.css' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_debugbar/assets/stylesheets',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\AssetController@css',
        'as' => 'debugbar.assets.css',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\AssetController@css',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.assets.js' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_debugbar/assets/javascript',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\AssetController@js',
        'as' => 'debugbar.assets.js',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\AssetController@js',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.cache.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '_debugbar/cache/{key}/{tags?}',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\CacheController@delete',
        'as' => 'debugbar.cache.delete',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\CacheController@delete',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sY0OqzMI4Ue1YxZc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::sY0OqzMI4Ue1YxZc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xku2l1aozMbUQiA4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:297:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:79:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000e930000000000000000";}";s:4:"hash";s:44:"4VGPRl2xXoUY7Url4voj9ByyYLwxB7HByyiPg18PXk4=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::xku2l1aozMbUQiA4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'krayin.home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Controller@redirectToLogin',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Controller@redirectToLogin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'krayin.home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tautkxCfhN4DyrCS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Controller@redirectToLogin',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Controller@redirectToLogin',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::tautkxCfhN4DyrCS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.session.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\User\\SessionController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\User\\SessionController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.session.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.session.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\User\\SessionController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\User\\SessionController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.session.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.forgot_password.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\User\\ForgotPasswordController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\User\\ForgotPasswordController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.forgot_password.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.forgot_password.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\User\\ForgotPasswordController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\User\\ForgotPasswordController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.forgot_password.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.reset_password.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/reset-password/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\User\\ResetPasswordController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\User\\ResetPasswordController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.reset_password.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.reset_password.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\User\\ResetPasswordController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\User\\ResetPasswordController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.reset_password.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.mail.inbound_parse' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/mail/inbound-parse',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@inboundParse',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@inboundParse',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.mail.inbound_parse',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.session.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\User\\SessionController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\User\\SessionController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.session.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dashboard.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Admin\\DashboardController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Admin\\DashboardController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.dashboard.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dashboard.template' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/template',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Admin\\DashboardController@template',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Admin\\DashboardController@template',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.dashboard.template',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.api.dashboard.card.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/api/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Admin\\DashboardController@getCardData',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Admin\\DashboardController@getCardData',
        'namespace' => NULL,
        'prefix' => 'admin/api/dashboard',
        'where' => 
        array (
        ),
        'as' => 'admin.api.dashboard.card.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.api.dashboard.cards.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/api/dashboard/cards',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Admin\\DashboardController@getCards',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Admin\\DashboardController@getCards',
        'namespace' => NULL,
        'prefix' => 'admin/api/dashboard',
        'where' => 
        array (
        ),
        'as' => 'admin.api.dashboard.cards.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.api.dashboard.cards.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/api/dashboard/cards',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Admin\\DashboardController@updateCards',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Admin\\DashboardController@updateCards',
        'namespace' => NULL,
        'prefix' => 'admin/api/dashboard',
        'where' => 
        array (
        ),
        'as' => 'admin.api.dashboard.cards.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.user.account.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/account',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\User\\AccountController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\User\\AccountController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\User',
        'prefix' => 'admin/account',
        'where' => 
        array (
        ),
        'as' => 'admin.user.account.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.user.account.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/account/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\User\\AccountController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\User\\AccountController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\User',
        'prefix' => 'admin/account',
        'where' => 
        array (
        ),
        'as' => 'admin.user.account.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/leads/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@create',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/leads/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/leads/view/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@view',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@view',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/leads/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/leads/search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@search',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@search',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.search',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/leads/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.mass_update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/leads/mass-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@massUpdate',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@massUpdate',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.mass_update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.mass_delete' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/leads/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@massDestroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@massDestroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.mass_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.tags.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/leads/tags/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\TagController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\TagController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.tags.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.tags.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/leads/{lead_id}/{tag_id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\TagController@delete',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\TagController@delete',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.tags.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.get' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/leads/get/{pipeline_id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@get',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@get',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.get',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/leads/{pipeline_id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\LeadController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leads.quotes.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/leads/quotes/{lead_id}/{quote_id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\QuoteController@delete',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Lead\\QuoteController@delete',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Lead',
        'prefix' => 'admin/leads/quotes',
        'where' => 
        array (
        ),
        'as' => 'admin.leads.quotes.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quotes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Quote',
        'prefix' => 'admin/quotes',
        'where' => 
        array (
        ),
        'as' => 'admin.quotes.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quotes.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/quotes/create/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@create',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Quote',
        'prefix' => 'admin/quotes',
        'where' => 
        array (
        ),
        'as' => 'admin.quotes.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quotes.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/quotes/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Quote',
        'prefix' => 'admin/quotes',
        'where' => 
        array (
        ),
        'as' => 'admin.quotes.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quotes.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/quotes/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Quote',
        'prefix' => 'admin/quotes',
        'where' => 
        array (
        ),
        'as' => 'admin.quotes.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quotes.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/quotes/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Quote',
        'prefix' => 'admin/quotes',
        'where' => 
        array (
        ),
        'as' => 'admin.quotes.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quotes.print' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/quotes/print/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@print',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@print',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Quote',
        'prefix' => 'admin/quotes',
        'where' => 
        array (
        ),
        'as' => 'admin.quotes.print',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quotes.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/quotes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Quote',
        'prefix' => 'admin/quotes',
        'where' => 
        array (
        ),
        'as' => 'admin.quotes.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quotes.mass_delete' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/quotes/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@massDestroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Quote\\QuoteController@massDestroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Quote',
        'prefix' => 'admin/quotes',
        'where' => 
        array (
        ),
        'as' => 'admin.quotes.mass_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activities.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/activities',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Activity',
        'prefix' => 'admin/activities',
        'where' => 
        array (
        ),
        'as' => 'admin.activities.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activities.get' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/activities/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@get',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@get',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Activity',
        'prefix' => 'admin/activities',
        'where' => 
        array (
        ),
        'as' => 'admin.activities.get',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activities.check_overlapping' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/activities/is-overlapping',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@checkIfOverlapping',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@checkIfOverlapping',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Activity',
        'prefix' => 'admin/activities',
        'where' => 
        array (
        ),
        'as' => 'admin.activities.check_overlapping',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activities.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/activities/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Activity',
        'prefix' => 'admin/activities',
        'where' => 
        array (
        ),
        'as' => 'admin.activities.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activities.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/activities/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Activity',
        'prefix' => 'admin/activities',
        'where' => 
        array (
        ),
        'as' => 'admin.activities.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activities.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/activities/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Activity',
        'prefix' => 'admin/activities',
        'where' => 
        array (
        ),
        'as' => 'admin.activities.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activities.search_participants' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/activities/search-participants',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@searchParticipants',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@searchParticipants',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Activity',
        'prefix' => 'admin/activities',
        'where' => 
        array (
        ),
        'as' => 'admin.activities.search_participants',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activities.file_upload' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/activities/file-upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@upload',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@upload',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Activity',
        'prefix' => 'admin/activities',
        'where' => 
        array (
        ),
        'as' => 'admin.activities.file_upload',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activities.file_download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/activities/file-download/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@download',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@download',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Activity',
        'prefix' => 'admin/activities',
        'where' => 
        array (
        ),
        'as' => 'admin.activities.file_download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activities.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/activities/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Activity',
        'prefix' => 'admin/activities',
        'where' => 
        array (
        ),
        'as' => 'admin.activities.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activities.mass_update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/activities/mass-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@massUpdate',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@massUpdate',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Activity',
        'prefix' => 'admin/activities',
        'where' => 
        array (
        ),
        'as' => 'admin.activities.mass_update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activities.mass_delete' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/activities/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@massDestroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Activity\\ActivityController@massDestroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Activity',
        'prefix' => 'admin/activities',
        'where' => 
        array (
        ),
        'as' => 'admin.activities.mass_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.mail.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/mail/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Mail',
        'prefix' => 'admin/mail',
        'where' => 
        array (
        ),
        'as' => 'admin.mail.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.mail.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/mail/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Mail',
        'prefix' => 'admin/mail',
        'where' => 
        array (
        ),
        'as' => 'admin.mail.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.mail.attachment_download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/mail/attachment-download/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@download',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@download',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Mail',
        'prefix' => 'admin/mail',
        'where' => 
        array (
        ),
        'as' => 'admin.mail.attachment_download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.mail.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/mail/{route?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Mail',
        'prefix' => 'admin/mail',
        'where' => 
        array (
        ),
        'as' => 'admin.mail.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.mail.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/mail/{route?}/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@view',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@view',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Mail',
        'prefix' => 'admin/mail',
        'where' => 
        array (
        ),
        'as' => 'admin.mail.view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.mail.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/mail/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Mail',
        'prefix' => 'admin/mail',
        'where' => 
        array (
        ),
        'as' => 'admin.mail.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.mail.mass_update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/mail/mass-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@massUpdate',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@massUpdate',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Mail',
        'prefix' => 'admin/mail',
        'where' => 
        array (
        ),
        'as' => 'admin.mail.mass_update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.mail.mass_delete' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/mail/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@massDestroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Mail\\EmailController@massDestroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Mail',
        'prefix' => 'admin/mail',
        'where' => 
        array (
        ),
        'as' => 'admin.mail.mass_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.persons.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/contacts/persons',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/persons',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.persons.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.persons.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/contacts/persons/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@create',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/persons',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.persons.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.persons.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/contacts/persons/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/persons',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.persons.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.persons.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/contacts/persons/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/persons',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.persons.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.persons.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/contacts/persons/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/persons',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.persons.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.persons.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/contacts/persons/search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@search',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@search',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/persons',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.persons.search',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.persons.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/contacts/persons/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
          3 => 'throttle:100,60',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/persons',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.persons.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.persons.mass_delete' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/contacts/persons/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@massDestroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\PersonController@massDestroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/persons',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.persons.mass_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.organizations.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/contacts/organizations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/organizations',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.organizations.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.organizations.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/contacts/organizations/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@create',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/organizations',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.organizations.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.organizations.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/contacts/organizations/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/organizations',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.organizations.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.organizations.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/contacts/organizations/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/organizations',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.organizations.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.organizations.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/contacts/organizations/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/organizations',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.organizations.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.organizations.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/contacts/organizations/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/organizations',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.organizations.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.contacts.organizations.mass_delete' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/contacts/organizations/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@massDestroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Contact\\OrganizationController@massDestroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Contact',
        'prefix' => 'admin/contacts/organizations',
        'where' => 
        array (
        ),
        'as' => 'admin.contacts.organizations.mass_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Product',
        'prefix' => 'admin/products',
        'where' => 
        array (
        ),
        'as' => 'admin.products.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/products/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@create',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Product',
        'prefix' => 'admin/products',
        'where' => 
        array (
        ),
        'as' => 'admin.products.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/products/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Product',
        'prefix' => 'admin/products',
        'where' => 
        array (
        ),
        'as' => 'admin.products.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/products/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Product',
        'prefix' => 'admin/products',
        'where' => 
        array (
        ),
        'as' => 'admin.products.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/products/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Product',
        'prefix' => 'admin/products',
        'where' => 
        array (
        ),
        'as' => 'admin.products.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/products/search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@search',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@search',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Product',
        'prefix' => 'admin/products',
        'where' => 
        array (
        ),
        'as' => 'admin.products.search',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/products/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Product',
        'prefix' => 'admin/products',
        'where' => 
        array (
        ),
        'as' => 'admin.products.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.mass_delete' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/products/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@massDestroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Product\\ProductController@massDestroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Product',
        'prefix' => 'admin/products',
        'where' => 
        array (
        ),
        'as' => 'admin.products.mass_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\SettingController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\SettingController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.groups.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\GroupController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\GroupController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/groups',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.groups.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.groups.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/groups/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\GroupController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\GroupController@create',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/groups',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.groups.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.groups.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/settings/groups/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\GroupController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\GroupController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/groups',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.groups.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.groups.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/groups/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\GroupController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\GroupController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/groups',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.groups.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.groups.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/groups/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\GroupController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\GroupController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/groups',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.groups.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.groups.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/settings/groups/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\GroupController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\GroupController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/groups',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.groups.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.roles.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\RoleController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\RoleController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/roles',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.roles.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.roles.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/roles/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\RoleController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\RoleController@create',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/roles',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.roles.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.roles.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/settings/roles/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\RoleController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\RoleController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/roles',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.roles.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.roles.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/roles/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\RoleController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\RoleController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/roles',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.roles.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.roles.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/roles/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\RoleController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\RoleController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/roles',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.roles.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.roles.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/settings/roles/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\RoleController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\RoleController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/roles',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.roles.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.users.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/users',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.users.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.users.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/users/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@create',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/users',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.users.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.users.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/settings/users/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/users',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.users.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.users.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/users/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/users',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.users.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.users.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/users/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/users',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.users.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.users.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/settings/users/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/users',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.users.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.users.mass_update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/users/mass-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@massUpdate',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@massUpdate',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/users',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.users.mass_update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.users.mass_delete' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/users/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@massDestroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\UserController@massDestroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/users',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.users.mass_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.attributes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/attributes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/attributes',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.attributes.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.attributes.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/attributes/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@create',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/attributes',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.attributes.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.attributes.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/settings/attributes/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/attributes',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.attributes.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.attributes.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/attributes/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/attributes',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.attributes.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.attributes.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/attributes/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/attributes',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.attributes.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.attributes.lookup' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/attributes/lookup/{lookup?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@lookup',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@lookup',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/attributes',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.attributes.lookup',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.attributes.lookup_entity' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/attributes/lookup-entity/{lookup?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@lookupEntity',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@lookupEntity',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/attributes',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.attributes.lookup_entity',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.attributes.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/settings/attributes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/attributes',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.attributes.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.attributes.mass_update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/attributes/mass-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@massUpdate',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@massUpdate',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/attributes',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.attributes.mass_update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.attributes.mass_delete' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/attributes/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@massDestroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@massDestroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/attributes',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.attributes.mass_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.attributes.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/attributes/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@download',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\AttributeController@download',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/attributes',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.attributes.download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.pipelines.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/pipelines',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\PipelineController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\PipelineController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/pipelines',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.pipelines.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.pipelines.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/pipelines/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\PipelineController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\PipelineController@create',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/pipelines',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.pipelines.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.pipelines.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/settings/pipelines/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\PipelineController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\PipelineController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/pipelines',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.pipelines.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.pipelines.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/pipelines/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\PipelineController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\PipelineController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/pipelines',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.pipelines.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.pipelines.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/pipelines/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\PipelineController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\PipelineController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/pipelines',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.pipelines.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.pipelines.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/settings/pipelines/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\PipelineController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\PipelineController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/pipelines',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.pipelines.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.sources.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/sources',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\SourceController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\SourceController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/sources',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.sources.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.sources.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/settings/sources/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\SourceController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\SourceController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/sources',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.sources.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.sources.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/sources/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\SourceController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\SourceController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/sources',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.sources.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.sources.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/sources/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\SourceController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\SourceController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/sources',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.sources.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.sources.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/settings/sources/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\SourceController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\SourceController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/sources',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.sources.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.types.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/types',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TypeController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TypeController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/types',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.types.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.types.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/settings/types/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TypeController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TypeController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/types',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.types.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.types.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/types/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TypeController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TypeController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/types',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.types.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.types.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/types/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TypeController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TypeController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/types',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.types.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.types.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/settings/types/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TypeController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TypeController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/types',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.types.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.email_templates.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/email-templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\EmailTemplateController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\EmailTemplateController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/email-templates',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.email_templates.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.email_templates.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/email-templates/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\EmailTemplateController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\EmailTemplateController@create',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/email-templates',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.email_templates.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.email_templates.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/settings/email-templates/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\EmailTemplateController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\EmailTemplateController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/email-templates',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.email_templates.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.email_templates.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/email-templates/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\EmailTemplateController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\EmailTemplateController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/email-templates',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.email_templates.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.email_templates.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/email-templates/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\EmailTemplateController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\EmailTemplateController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/email-templates',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.email_templates.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.email_templates.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/settings/email-templates/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\EmailTemplateController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\EmailTemplateController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/email-templates',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.email_templates.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.workflows.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/workflows',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\WorkflowController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\WorkflowController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/workflows',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.workflows.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.workflows.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/workflows/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\WorkflowController@create',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\WorkflowController@create',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/workflows',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.workflows.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.workflows.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/settings/workflows/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\WorkflowController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\WorkflowController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/workflows',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.workflows.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.workflows.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/workflows/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\WorkflowController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\WorkflowController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/workflows',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.workflows.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.workflows.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/workflows/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\WorkflowController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\WorkflowController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/workflows',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.workflows.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.workflows.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/settings/workflows/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\WorkflowController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\WorkflowController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/workflows',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.workflows.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.tags.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/tags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/tags',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.tags.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.tags.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/settings/tags/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/tags',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.tags.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.tags.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/tags/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@edit',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@edit',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/tags',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.tags.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.tags.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/tags/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@update',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@update',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/tags',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.tags.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.tags.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings/tags/search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@search',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@search',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/tags',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.tags.search',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.tags.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/settings/tags/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@destroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@destroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/tags',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.tags.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.tags.mass_delete' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings/tags/mass-destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@massDestroy',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Setting\\TagController@massDestroy',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Setting',
        'prefix' => 'admin/settings/tags',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.tags.mass_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.configuration.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/configuration/{slug?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Configuration\\ConfigurationController@index',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Configuration\\ConfigurationController@index',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Configuration',
        'prefix' => 'admin/configuration',
        'where' => 
        array (
        ),
        'as' => 'admin.configuration.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.configuration.index.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/configuration/{slug?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_locale',
          2 => 'user',
        ),
        'uses' => 'Webkul\\Admin\\Http\\Controllers\\Configuration\\ConfigurationController@store',
        'controller' => 'Webkul\\Admin\\Http\\Controllers\\Configuration\\ConfigurationController@store',
        'namespace' => 'Webkul\\Admin\\Http\\Controllers\\Configuration',
        'prefix' => 'admin/configuration',
        'where' => 
        array (
        ),
        'as' => 'admin.configuration.index.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ui.datagrid.export' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'user',
        ),
        'uses' => 'Webkul\\UI\\Http\\Controllers\\ExportController@export',
        'controller' => 'Webkul\\UI\\Http\\Controllers\\ExportController@export',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ui.datagrid.export',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.web_forms.form_js' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/web-forms/forms/{id}/form.js',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@formJS',
        'controller' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@formJS',
        'namespace' => 'Webkul\\WebForm\\Http\\Controllers',
        'prefix' => 'admin/web-forms',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.web_forms.form_js',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.web_forms.preview' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/web-forms/forms/{id}/form.html',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@preview',
        'controller' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@preview',
        'namespace' => 'Webkul\\WebForm\\Http\\Controllers',
        'prefix' => 'admin/web-forms',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.web_forms.preview',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.web_forms.form_store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/web-forms/forms/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@formStore',
        'controller' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@formStore',
        'namespace' => 'Webkul\\WebForm\\Http\\Controllers',
        'prefix' => 'admin/web-forms',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.web_forms.form_store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.web_forms.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/web-forms',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'user',
        ),
        'uses' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@index',
        'controller' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@index',
        'namespace' => 'Webkul\\WebForm\\Http\\Controllers',
        'prefix' => 'admin/web-forms',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.web_forms.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.web_forms.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/web-forms/form/{id}/form.html',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'user',
        ),
        'uses' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@view',
        'controller' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@view',
        'namespace' => 'Webkul\\WebForm\\Http\\Controllers',
        'prefix' => 'admin/web-forms',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.web_forms.view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.web_forms.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/web-forms/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'user',
        ),
        'uses' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@create',
        'controller' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@create',
        'namespace' => 'Webkul\\WebForm\\Http\\Controllers',
        'prefix' => 'admin/web-forms',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.web_forms.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.web_forms.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/web-forms/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'user',
        ),
        'uses' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@store',
        'controller' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@store',
        'namespace' => 'Webkul\\WebForm\\Http\\Controllers',
        'prefix' => 'admin/web-forms',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.web_forms.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.web_forms.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/web-forms/edit/{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'user',
        ),
        'uses' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@edit',
        'controller' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@edit',
        'namespace' => 'Webkul\\WebForm\\Http\\Controllers',
        'prefix' => 'admin/web-forms',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.web_forms.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.web_forms.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/web-forms/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'user',
        ),
        'uses' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@update',
        'controller' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@update',
        'namespace' => 'Webkul\\WebForm\\Http\\Controllers',
        'prefix' => 'admin/web-forms',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.web_forms.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.web_forms.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/web-forms/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'user',
        ),
        'uses' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@destroy',
        'controller' => 'Webkul\\WebForm\\Http\\Controllers\\WebFormController@destroy',
        'namespace' => 'Webkul\\WebForm\\Http\\Controllers',
        'prefix' => 'admin/web-forms',
        'where' => 
        array (
        ),
        'as' => 'admin.settings.web_forms.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
