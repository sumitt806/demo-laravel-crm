<?php

namespace Webkul\Contact\Models;

use Konekt\Concord\Proxies\ModelProxy;

class PersonProxy extends ModelProxy
{

}