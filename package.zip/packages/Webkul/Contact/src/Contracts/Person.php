<?php

namespace Webkul\Contact\Contracts;

interface Person
{
}