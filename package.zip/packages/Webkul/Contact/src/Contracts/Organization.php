<?php

namespace Webkul\Contact\Contracts;

interface Organization
{
}