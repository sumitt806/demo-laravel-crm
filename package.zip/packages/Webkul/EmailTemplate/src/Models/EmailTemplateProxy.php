<?php

namespace Webkul\EmailTemplate\Models;

use Konekt\Concord\Proxies\ModelProxy;

class EmailTemplateProxy extends ModelProxy
{

}