<?php

namespace Webkul\Tag\Contracts;

interface Tag
{
}