<?php

namespace Webkul\Tag\Models;

use Konekt\Concord\Proxies\ModelProxy;

class TagProxy extends ModelProxy
{

}