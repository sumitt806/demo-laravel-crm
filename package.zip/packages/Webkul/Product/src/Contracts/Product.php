<?php

namespace Webkul\Product\Contracts;

interface Product
{
}