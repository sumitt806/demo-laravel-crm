<?php

namespace Webkul\Email\Contracts;

interface Email
{
}